
mods.immersiveengineering.Mixer.addRecipe(<liquid:pyrotheum>*250, <liquid:lava>*250, [<minecraft:blaze_powder>,<minecraft:blaze_powder>,<ore:dustRedstone>, <ore:dustSulfur>], 2048);
mods.immersiveengineering.Mixer.addRecipe(<liquid:cryotheum>*250, <liquid:water>*250, [<netherex:rime_crystal>,<netherex:rime_crystal>,<ore:dustRedstone>, <minecraft:snowball>], 2048);
mods.immersiveengineering.Mixer.addRecipe(<liquid:aerotheum>*250, <liquid:water>*250, [<ore:dustSaltpeter>,<ore:dustSaltpeter>,<ore:dustRedstone>, <minecraft:prismarine_shard>], 2048);
mods.immersiveengineering.Mixer.addRecipe(<liquid:petrotheum>*250, <liquid:lava>*250, [<ore:dustObsidian>,<ore:dustObsidian>,<ore:dustRedstone>, <ore:dustCoal>], 2048);